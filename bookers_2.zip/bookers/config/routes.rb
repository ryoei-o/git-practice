Rails.application.routes.draw do
  delete 'books/:id' => 'books#destroy', as: 'destroy_book'
  
  post 'books/:id' => 'books#edit'
  patch 'books/:id' => 'books#update', as: 'update_book'
  resources :books
  root :to => 'homes#top'
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
